Python 3.7.0 (v3.7.0:1bf9cc5093, Jun 26 2018, 23:26:24) 
[Clang 6.0 (clang-600.0.57)] on darwin
Type "copyright", "credits" or "license()" for more information.
>>> # -------------------------------------------------#
# Project: Python programming
# Name: Assignment 06
# Title: Working with functions
# Purpose: Learning and practices more
# Author: Jean-Baptiste Yamindi
# Created: 08/18/2018
# References:
# https://www.youtube.com/playlist?list=PLfycUyp06LG-7xrsqU6kCTOXr2TLDPgD2
# http://www.tutorialspoint.com/python/python_functions.htm
# -------------------------------------------------#

# -- Data information--#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary using a function
# lstTable = A dictionary that acts as a 'table' of rows using a fucntion
# strMenu = A menu of user options of the function
# strChoice = Capture the user option selection of the function

# -- Input/Output --#
# get user input
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 )
# return a value from the function and send program output (Step 5)
# User can save to file (Step 6)
# send program output

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into dictionaries using Functions and a Class.


# Step 2
# Display a menu of choices to the user

# Step 3
# perform values
# Display all todo values to user

# Step 4
# Add a new value to Functions and a Class or overwrite the original function

# Step 5
# Remove a new value to Functions and a Class

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# ----------------------------------------
objFileName = "/Users/jean-baptisteyamindi/Desktop/Foundation_Python2018/Module06/Todo.txt"
# declare variables and constants
strData = ""
dicRow = {}
lstTable = []
v1 = None  # first argument
v2 = None  # second argument
lstData = None  # result of processing

# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary using Functions and a Class.
objFile = open(objFileName, "r")
for line in objFile:
    strData = line.split(",")  # readline() reads a line of the data into 2 elements
    dicRow = {"value1": strData[0].strip(), "value2": strData[1].strip()}
lstTable == lstResults
lstTable.append(dicRow)
# get user input function
value1 = float(input("Enter the first number: "))
value2 = float(input("Enter the second number: "))
# Define the function
Def
AddValues(value1, value2):
decAnswer = value1 + value2
lstResults = [decAnswer, value1, value2]
return lstResults
objFile.close()

# Step 2
# Display a function menu of choices to the user
while (True):
    print ("""
    Menu of Options
    1) Show current values data
    2) Add a new value into Function and a Class or overwrite the original function
    3) Remove an existing value from Function and a Class.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line

    # Step 3
    # Show the current value into Function and a Class
    if (strChoice.strip() == '1'):
        print("******* The current values ToDo are: *******")
        for row in lstResults:
            print("The sum of the values"+lstData[1]) +"and" +(lstData[2]+ "is" + lstData[0])
            print("*******************************************")
        # Step 4
        # This would overwrite the original function
    elif (strChoice.strip() == "2"):
        value1 = float(input("What is the Value1?_")).strip()
        value2 = float(input("What is the Value2?_ ")).strip()
        value3 = float(input("What is the Value3?_ ")).strip()
    dicRow = {" value1": float(value1), " Value2": float(value2), ), " Value3": float(value3)}
    lstResults = lstTable 
    lstTable.append(dicRow)
    def AddValues(value1, value2, value3):
        decAnswer = value1 + value2 + value3
        lstResults = [decAnswer, value1, value2, value3]
        return lstResults
    
    print("Current values Data in table:")
    for dicRow in lstTable:
        print(dicRow)

    # 4a Show the current value into Function and a Class
    # Define the function
    def AddValues(value1 = None, value2 = None, value3 = None):
    lstResults = None  # Holds results list
    if (value3 is None):
        decAnswer = value1 + value2
        lstResults = [decAnswer, value1, value2]
        elif:
        decAnswer = value1 + value2 + value3
        lstResults = [decAnswer, value1, value2, value3]
        return lstResults
    # Call function
    lstData = AddValues(12, 6)
    print(lstData)
    lstData = AddValues(12, 6, 8)
    print(lstData)
print("******* The current value ToDo are: *******")
for row in lstTable:
    print(row["Value1"] + "Value2"] +  "(" + row["Value3"] + ")")
    print(“The overwrite sum of the original function values” + lstData[1] + ” and “+ lstData[2] + "and " + lstData[3] + "is: " + lstData[0])
    print("*******************************************")
    continue  # to show the menu

# Step 5
# Remove a new value into Function and a Class
elif (strChoice == "3"):
# 5a-Allow user to indicate which row to delete
    strValueToRemove = input("Which Value1 would you like removed? - ")
    blnValueRemoved = False  # Creating a boolean Flag
    intRowNumber = 0
while (intRowNumber < len(lstTable)):
    if (strValueToRemove == str(list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
        del lstTable[intRowNumber]
        blnValueRemoved = True
    # end if
    intRowNumber += 1
# end for loop
# 5b-Update user on the status
if (blnValueRemoved == True):
    print("The value was removed.")
else:
    print("I'm sorry, but I could not find that value.")

# 5c Show the current items in the table
print("******* The current value ToDo are: *******")
for row in lstTable:
    print(row["Value1"] + "(" + row["Value2"] + ")")
print("*******************************************")
continue  # to show the menu

# Step 6
# Save values to the ToDo.txt file
elif (strChoice == '4'):
# 5a Show the current values in the table
print("******* The current values ToDo are: *******")
for row in lstTable:
    print(row["Value1"] + ["Value2"] + "(" + row["Value3"] + ")")
print("*******************************************")
# 5b Ask if they want save that data
if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
    objFile = open(objFileName, "w")
    for dicRow in lstTable:
        objFile.write(dicRow["Value1"] + "," + dicRow["Value2"] + dicRow["Value3"] + "\n")
    objFile.close()
    input("Data saved to file! Press the [Enter] key to return to menu.")
else:
    input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")
continue  # to show the menu
elif (strChoice == '5'):
break  # and Exit the program

